-- Core private learning data for IELTS + HSK.
-- Shared vocabulary remains in vocab-data.js; this migration stores only user data.
begin;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_settings (
  user_id uuid not null references auth.users(id) on delete cascade,
  language text not null check (language in ('ielts', 'hsk')),
  daily_new_goal integer not null default 20 check (daily_new_goal between 1 and 200),
  daily_review_goal integer check (daily_review_goal between 1 and 500),
  level_code text,
  selected_topics text[] not null default '{}',
  preferences jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (user_id, language)
);

create table if not exists public.user_vocabulary_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  language text not null check (language in ('ielts', 'hsk')),
  corpus_key text not null,
  topic_id text not null,
  word_key text not null,
  status text not null default 'new' check (status in ('new', 'learning', 'known', 'suspended')),
  is_favorite boolean not null default false,
  interval_days integer not null default 0 check (interval_days >= 0),
  ease_factor numeric(4,2) not null default 2.50 check (ease_factor between 1.30 and 3.50),
  repetitions integer not null default 0 check (repetitions >= 0),
  lapses integer not null default 0 check (lapses >= 0),
  due_at timestamptz,
  last_reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id, language, corpus_key, topic_id, word_key)
);

create table if not exists public.study_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  language text not null check (language in ('ielts', 'hsk')),
  started_at timestamptz not null default now(),
  ended_at timestamptz,
  new_words integer not null default 0 check (new_words >= 0),
  reviews integer not null default 0 check (reviews >= 0),
  correct_answers integer not null default 0 check (correct_answers >= 0),
  total_answers integer not null default 0 check (total_answers >= 0),
  created_at timestamptz not null default now(),
  unique (id, user_id)
);

create table if not exists public.study_answers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  session_id uuid not null,
  language text not null check (language in ('ielts', 'hsk')),
  corpus_key text not null,
  topic_id text not null,
  word_key text not null,
  mode text not null check (mode in ('flashcard', 'quiz', 'write', 'match', 'pinyin', 'translation', 'listening')),
  answer_text text,
  is_correct boolean,
  response_ms integer check (response_ms is null or response_ms >= 0),
  answered_at timestamptz not null default now(),
  foreign key (session_id, user_id) references public.study_sessions(id, user_id) on delete cascade
);

create table if not exists public.exercises (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  language text not null check (language in ('ielts', 'hsk')),
  exercise_type text not null check (exercise_type in ('sentence', 'paragraph', 'mixed', 'weak_words')),
  direction text not null check (direction in ('vi-en', 'en-vi', 'vi-zh', 'zh-vi')),
  difficulty text not null check (difficulty in ('beginner', 'intermediate', 'advanced')),
  config jsonb not null default '{}'::jsonb,
  prompts jsonb not null default '[]'::jsonb,
  provider text,
  model text,
  created_at timestamptz not null default now(),
  unique (id, user_id)
);

create table if not exists public.exercise_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  exercise_id uuid not null,
  answers jsonb not null default '[]'::jsonb,
  score numeric(5,2) check (score is null or score between 0 and 100),
  feedback jsonb not null default '[]'::jsonb,
  started_at timestamptz not null default now(),
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  unique (id, user_id),
  foreign key (exercise_id, user_id) references public.exercises(id, user_id) on delete cascade
);

create table if not exists public.correction_errors (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  attempt_id uuid not null,
  language text not null check (language in ('ielts', 'hsk')),
  category text not null,
  original_text text not null,
  suggested_text text,
  explanation text,
  example_text text,
  created_at timestamptz not null default now(),
  foreign key (attempt_id, user_id) references public.exercise_attempts(id, user_id) on delete cascade
);

create table if not exists public.ai_conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  language text not null check (language in ('ielts', 'hsk')),
  title text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (id, user_id)
);

create table if not exists public.ai_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  conversation_id uuid not null,
  role text not null check (role in ('user', 'assistant')),
  content text not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  foreign key (conversation_id, user_id) references public.ai_conversations(id, user_id) on delete cascade
);

-- Written by trusted Edge Functions only; authenticated clients may read their own usage.
create table if not exists public.ai_usage_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  task text not null check (task in ('chat', 'exercise_generation', 'grading', 'explanation')),
  provider text not null,
  model text not null,
  status text not null check (status in ('success', 'error', 'rate_limited')),
  input_tokens integer check (input_tokens is null or input_tokens >= 0),
  output_tokens integer check (output_tokens is null or output_tokens >= 0),
  estimated_cost numeric(12,6) check (estimated_cost is null or estimated_cost >= 0),
  created_at timestamptz not null default now()
);

create index if not exists user_progress_due_idx
  on public.user_vocabulary_progress (user_id, language, due_at)
  where due_at is not null and status <> 'suspended';
create index if not exists user_progress_status_idx
  on public.user_vocabulary_progress (user_id, language, status);
create index if not exists study_sessions_recent_idx
  on public.study_sessions (user_id, language, started_at desc);
create index if not exists study_answers_recent_idx
  on public.study_answers (user_id, language, answered_at desc);
create index if not exists study_answers_word_idx
  on public.study_answers (user_id, language, corpus_key, topic_id, word_key, answered_at desc);
create index if not exists exercises_recent_idx
  on public.exercises (user_id, language, created_at desc);
create index if not exists attempts_recent_idx
  on public.exercise_attempts (user_id, created_at desc);
create index if not exists correction_errors_recent_idx
  on public.correction_errors (user_id, language, category, created_at desc);
create index if not exists ai_conversations_recent_idx
  on public.ai_conversations (user_id, language, updated_at desc);
create index if not exists ai_messages_conversation_idx
  on public.ai_messages (user_id, conversation_id, created_at);
create index if not exists ai_usage_logs_recent_idx
  on public.ai_usage_logs (user_id, created_at desc);

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();
drop trigger if exists settings_set_updated_at on public.user_settings;
create trigger settings_set_updated_at before update on public.user_settings
  for each row execute function public.set_updated_at();
drop trigger if exists progress_set_updated_at on public.user_vocabulary_progress;
create trigger progress_set_updated_at before update on public.user_vocabulary_progress
  for each row execute function public.set_updated_at();
drop trigger if exists conversations_set_updated_at on public.ai_conversations;
create trigger conversations_set_updated_at before update on public.ai_conversations
  for each row execute function public.set_updated_at();

create or replace function public.create_profile_for_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', new.email));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_profile on auth.users;
create trigger on_auth_user_created_profile after insert on auth.users
  for each row execute function public.create_profile_for_new_user();

alter table public.profiles enable row level security;
alter table public.user_settings enable row level security;
alter table public.user_vocabulary_progress enable row level security;
alter table public.study_sessions enable row level security;
alter table public.study_answers enable row level security;
alter table public.exercises enable row level security;
alter table public.exercise_attempts enable row level security;
alter table public.correction_errors enable row level security;
alter table public.ai_conversations enable row level security;
alter table public.ai_messages enable row level security;
alter table public.ai_usage_logs enable row level security;

drop policy if exists profiles_select_own on public.profiles;
create policy profiles_select_own on public.profiles for select to authenticated using (id = (select auth.uid()));
drop policy if exists profiles_insert_own on public.profiles;
create policy profiles_insert_own on public.profiles for insert to authenticated with check (id = (select auth.uid()));
drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));

drop policy if exists settings_manage_own on public.user_settings;
create policy settings_manage_own on public.user_settings for all to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists progress_manage_own on public.user_vocabulary_progress;
create policy progress_manage_own on public.user_vocabulary_progress for all to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists sessions_manage_own on public.study_sessions;
create policy sessions_manage_own on public.study_sessions for all to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists answers_manage_own on public.study_answers;
create policy answers_manage_own on public.study_answers for all to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists exercises_manage_own on public.exercises;
create policy exercises_manage_own on public.exercises for all to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists attempts_manage_own on public.exercise_attempts;
create policy attempts_manage_own on public.exercise_attempts for all to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists errors_manage_own on public.correction_errors;
create policy errors_manage_own on public.correction_errors for all to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists conversations_manage_own on public.ai_conversations;
create policy conversations_manage_own on public.ai_conversations for all to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists messages_manage_own on public.ai_messages;
create policy messages_manage_own on public.ai_messages for all to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists usage_read_own on public.ai_usage_logs;
create policy usage_read_own on public.ai_usage_logs for select to authenticated using (user_id = (select auth.uid()));

grant select, insert, update, delete on public.profiles to authenticated;
grant select, insert, update, delete on public.user_settings to authenticated;
grant select, insert, update, delete on public.user_vocabulary_progress to authenticated;
grant select, insert, update, delete on public.study_sessions to authenticated;
grant select, insert, update, delete on public.study_answers to authenticated;
grant select, insert, update, delete on public.exercises to authenticated;
grant select, insert, update, delete on public.exercise_attempts to authenticated;
grant select, insert, update, delete on public.correction_errors to authenticated;
grant select, insert, update, delete on public.ai_conversations to authenticated;
grant select, insert, update, delete on public.ai_messages to authenticated;
grant select on public.ai_usage_logs to authenticated;

commit;
