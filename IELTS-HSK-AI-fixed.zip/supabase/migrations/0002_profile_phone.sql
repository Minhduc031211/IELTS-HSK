-- Persist optional phone numbers on the server-side profile for each Supabase Auth user.
begin;

alter table public.profiles
  add column if not exists phone text;

grant select, insert, update on public.profiles to authenticated;

commit;
