# IELTS + HSK vocabulary app: Supabase setup

The main learning screen is `../index.html`, with its data in `../vocab-data.js`. The browser saves progress locally first. Signing in also syncs known and missed words across devices. Wrong-answer review is separated by HuyForum IELTS, IELTS by topic, and HSK.

## 1. Create the database tables

Run `setup-ai.ps1` from this folder to link the project and apply both migrations. Migration `0001_learning_platform.sql` creates per-user profiles and private learning tables; `0002_profile_phone.sql` adds the optional phone field. Row-level security limits each account to its own data. If migration 0001 is already applied, the CLI applies only migration 0002.

## 2. Deploy the AI service

Windows users can run `setup-ai.ps1` from this folder. It links the project, pushes the migration, and deploys the `vocab-assistant` Edge Function. It asks for the Supabase project ref and uses Supabase CLI sign-in; it never asks for the OpenAI key. If the database migration was already run manually, use the CLI migration repair flow or deploy the function separately instead of pushing the same migration again.

After deployment, open Supabase Dashboard → Edge Functions → Secrets and add `OPENAI_API_KEY`. Optionally add `OPENAI_MODEL` (default `gpt-4.1-mini`). The OpenAI key must stay in Edge Function secrets; never put it in the HTML, JavaScript, browser storage, or GitHub. Supabase applies a newly saved secret immediately. The function validates the signed-in user, reads only that user's progress for the personal tutor and translation exercises, limits successful AI calls to 30 per user per hour, and logs usage.

## 3. Connect the website

In Supabase Auth → URL Configuration, set your published website URL as Site URL and add it to Redirect URLs. For local Live Server testing, add `http://127.0.0.1:5500/**`. Email confirmation may be enabled; if so, open the confirmation email before signing in. The site header has separate **Đăng nhập** and **Đăng ký** buttons. The site owner adds the project URL and publishable key once in `supabase-config.js`; visitors then only use their own email and password. Supabase Auth stores unique account emails; the `profiles` table stores each user's name and phone on the server. Use HTTPS (GitHub Pages is fine); opening a local `file://` page may cause browser restrictions.

## Features included in the main screen

- The **Ôn từ sai** list stores misses from quiz, rewrite, matching, and HSK Pinyin practice. It is separate for each of the three word collections and removes a word after it is marked remembered.
- **Luyện dịch** creates a short exercise using learned words from the signed-in account, in English↔Vietnamese or Chinese↔Vietnamese directions, and provides AI feedback on the submitted translation.
- The AI dictionary lookup uses the search field. The lower-right AI tutor can refer to the current signed-in account's learned words.
- Without Supabase setup and an OpenAI key in Edge Function Secrets, AI requests and cross-device sync will not work; local learning and wrong-answer review still work.


## One-time public client configuration

Before publishing the shared web app, add the project's Supabase Publishable key (sb_publishable_...) to supabase-config.js in the key field. The Project URL is prefilled for the current project. This publishable key is designed to be used in browser apps; never put an OpenAI key or a Supabase secret/service-role key in this file. Once committed and deployed, visitors do not need to enter Supabase configuration. They only create or sign into their own learning account. For local testing, add http://127.0.0.1:5500/** to Auth → URL Configuration → Redirect URLs.
