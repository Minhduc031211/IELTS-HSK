$ErrorActionPreference = 'Stop'

Write-Host 'IELTS + HSK AI setup' -ForegroundColor Cyan
Write-Host 'This script links the Supabase project, applies any new database migrations, and deploys vocab-assistant.'
Write-Host 'It never asks for or stores your OpenAI API key.'
Write-Host ''

$projectRef = Read-Host 'Enter the Supabase project ref (Project Settings > General > Reference ID)'
if ([string]::IsNullOrWhiteSpace($projectRef)) {
  throw 'Project ref is required.'
}

$projectRoot = Split-Path -Parent $PSScriptRoot
if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'config.toml'))) {
  throw 'Could not find supabase/config.toml. Run this script from the extracted project package.'
}

Push-Location $projectRoot
try {
  Write-Host ''
  Write-Host '1/4  Signing in to Supabase CLI. Complete its prompts in this window.' -ForegroundColor Yellow
  & npx --yes supabase@latest login
  if ($LASTEXITCODE -ne 0) { throw 'Supabase CLI login did not complete.' }

  Write-Host ''
  Write-Host '2/4  Linking the Supabase project. The CLI may ask for your database password.' -ForegroundColor Yellow
  & npx --yes supabase@latest link --project-ref $projectRef
  if ($LASTEXITCODE -ne 0) { throw 'Could not link the project.' }

  Write-Host ''
  Write-Host '3/4  Applying the learning-platform migration.' -ForegroundColor Yellow
  & npx --yes supabase@latest db push
  if ($LASTEXITCODE -ne 0) { throw 'Database migration failed. Read the CLI message before retrying.' }

  Write-Host ''
  Write-Host '4/4  Deploying the AI Edge Function.' -ForegroundColor Yellow
  & npx --yes supabase@latest functions deploy vocab-assistant
  if ($LASTEXITCODE -ne 0) { throw 'Edge Function deployment failed.' }

  Write-Host ''
  Write-Host 'Setup deployed. Now add OPENAI_API_KEY in Supabase Dashboard > Edge Functions > Secrets.' -ForegroundColor Green
  Write-Host 'Add the project's Publishable key once in supabase-config.js. Website visitors then only need their own email and password.' -ForegroundColor Green
}
finally {
  Pop-Location
}
