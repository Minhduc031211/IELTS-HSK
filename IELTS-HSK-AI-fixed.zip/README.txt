IELTS & HSK Vocabulary — bản GitHub Pages + Supabase
=====================================================

Tài khoản, hồ sơ (email, tên, sđt) và tiến độ học được lưu trên Supabase,
nên trang chạy được trên GitHub Pages (không cần server riêng).

LÀM MỘT LẦN (chủ web)
1. Supabase Dashboard > Project Settings > API: copy "Publishable key" (sb_publishable_...).
   Mở supabase-config.js, dán vào key: ''  (KHÔNG dùng secret/service_role key).
2. Authentication > Providers: bật Email.
3. Authentication > URL Configuration:
   - Site URL: địa chỉ GitHub Pages, ví dụ https://TENBAN.github.io/TEN-REPO/
   - Redirect URLs: thêm cùng địa chỉ đó (có thêm /** ở cuối) và http://localhost:5500/** để thử trên máy.
4. Database: chạy supabase/setup-ai.ps1 (hoặc dán 2 file trong supabase/migrations vào SQL Editor
   nếu chưa chạy). Nếu bạn đã chạy trước đây thì không chạy lại 0001.
5. (Tuỳ chọn, để dùng AI) Edge Functions > Secrets: thêm OPENAI_API_KEY.
   Hàm vocab-assistant được deploy bởi setup-ai.ps1.

ĐƯA LÊN GITHUB PAGES
- Đẩy toàn bộ file lên repo, Settings > Pages > chọn nhánh main, thư mục /(root).
- Có thể xoá thư mục supabase/ khỏi repo sau khi cài xong nếu muốn (không bắt buộc).

SỬ DỤNG
- Nút Đăng ký / Đăng nhập ở thanh đầu trang. Sau khi đăng nhập hiện biểu tượng người dùng:
  bấm vào để xem Email, nhập Tên, Số điện thoại và bấm Lưu.
- Nếu Supabase bật "Confirm email", người dùng phải bấm link trong email xác nhận rồi mới đăng nhập được.
  Muốn bỏ bước này: Authentication > Providers > Email > tắt "Confirm email".
- Bấm ra ngoài khung hoặc phím Esc để đóng hộp thoại.
- Thử trên máy: mở thư mục bằng VS Code + Live Server (không dùng file://).
